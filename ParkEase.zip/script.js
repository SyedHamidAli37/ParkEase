import db from './firebase-config.js';
import {
  collection, addDoc, getDocs, query, where
} from "https://www.gstatic.com/firebasejs/10.10.0/firebase-firestore.js";

const slotRef = collection(db, "parking_slots");

document.getElementById("addForm").addEventListener("submit", async function (e) {
  e.preventDefault();

  const slotId = document.getElementById("slot_id").value.trim();
  const level = document.getElementById("level").value.trim();
  const plate = document.getElementById("plate").value.trim();
  const status = document.getElementById("status").value;

  if (!slotId || !level || !plate || !status) {
    alert("Please fill in all fields.");
    return;
  }

  try {
    await addDoc(slotRef, {
      slot_id: slotId,
      level: level,
      license_plate: plate.toUpperCase(),
      status: status,
      last_updated: new Date().toISOString()
    });
    alert("✅ Slot added successfully!");
    this.reset();
    fetchSlots();
  } catch (error) {
    console.error("Error adding slot:", error);
    alert("❌ Could not add slot.");
  }
});

window.fetchSlots = async function () {
  try {
    const snapshot = await getDocs(slotRef);
    const container = document.getElementById("slots");
    container.innerHTML = "";

    if (snapshot.empty) {
      container.innerHTML = "<p>No slots available yet.</p>";
      return;
    }

    snapshot.forEach(doc => {
      const d = doc.data();
      container.innerHTML += `
        <p>
          <strong>${d.slot_id}</strong> | ${d.status.toUpperCase()} | Level ${d.level} | Plate: ${d.license_plate}
          <button onclick="generateQRCode('${d.slot_id}')">📱 QR</button>
        </p>`;
    });
  } catch (error) {
    console.error(error);
    alert("❌ Error fetching data.");
  }
};

window.searchByPlate = async function () {
  const plate = document.getElementById("search_plate").value.trim().toUpperCase();
  if (!plate) return alert("Enter a plate number to search.");

  try {
    const q = query(slotRef, where("license_plate", "==", plate));
    const snapshot = await getDocs(q);
    const container = document.getElementById("slots");
    container.innerHTML = "";

    if (snapshot.empty) {
      container.innerHTML = `<p>❌ No results for plate: ${plate}</p>`;
      return;
    }

    snapshot.forEach(doc => {
      const d = doc.data();
      container.innerHTML += `
        <p>
          <strong>${d.slot_id}</strong> | ${d.status.toUpperCase()} | Level ${d.level} | Plate: ${d.license_plate}
          <button onclick="generateQRCode('${d.slot_id}')">📱 QR</button>
        </p>`;
    });
  } catch (err) {
    console.error(err);
    alert("❌ Search error.");
  }
};

window.generateQRCode = function (text) {
  const win = window.open("", "_blank", "width=300,height=300");
  win.document.write("<h3>Scan to find your slot</h3><div id='qrcode'></div>");
  const qrDiv = win.document.getElementById("qrcode");

  QRCode.toCanvas(text, { width: 250 }, function (err, canvas) {
    if (err) {
      win.document.body.innerHTML = "<p>Failed to generate QR</p>";
      return;
    }
    qrDiv.appendChild(canvas);
  });
};